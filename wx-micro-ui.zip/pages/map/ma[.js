// pages/map/ma[.js
