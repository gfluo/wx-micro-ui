// pages/map/ma[.js
